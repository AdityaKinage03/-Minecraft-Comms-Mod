package com.example.dialogue.client.events;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class DialogueEvents {

    // Track kills
    @SubscribeEvent
    public static void onEntityKilled(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;

        CompoundTag data = player.getPersistentData();
        if (!data.contains("activeQuest")) return;

        String quest = data.getString("activeQuest");

        if (quest.contains("zombies") && event.getEntity() instanceof Zombie) {
            incrementProgress(player, quest);
        }
    }

    // Track block breaking (stone mining)
    @SubscribeEvent
    public static void onBlockBreak(PlayerEvent.BreakSpeed event) {
        Player player = event.getEntity();
        CompoundTag data = player.getPersistentData();
        if (!data.contains("activeQuest")) return;

        String quest = data.getString("activeQuest");

        if (quest.contains("stone") && event.getState().getBlock().asItem() == Items.STONE) {
            incrementProgress(player, quest);
        }
    }

    // Track item collection (wheat/emeralds)
    @SubscribeEvent
    public static void onInventoryChange(PlayerEvent.ItemPickupEvent event) {
        Player player = event.getEntity();
        CompoundTag data = player.getPersistentData();
        if (!data.contains("activeQuest")) return;

        String quest = data.getString("activeQuest");

        if (quest.contains("wheat")) {
            int count = countItem(player, Items.WHEAT);
            data.putInt("questProgress", count);
            if (count >= data.getInt("questTarget")) {
                data.putBoolean("questComplete", true);
            }
        }

        if (quest.contains("emeralds")) {
            int count = countItem(player, Items.EMERALD);
            data.putInt("questProgress", count);
            if (count >= data.getInt("questTarget")) {
                data.putBoolean("questComplete", true);
            }
        }
    }

    // Helpers
    private static void incrementProgress(Player player, String quest) {
        CompoundTag data = player.getPersistentData();
        int progress = data.getInt("questProgress") + 1;
        int target = data.getInt("questTarget");

        data.putInt("questProgress", progress);
        if (progress >= target) {
            data.putBoolean("questComplete", true);
        }
    }

    private static int countItem(Player player, net.minecraft.world.item.Item item) {
        int total = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() == item) total += stack.getCount();
        }
        return total;
    }
}
