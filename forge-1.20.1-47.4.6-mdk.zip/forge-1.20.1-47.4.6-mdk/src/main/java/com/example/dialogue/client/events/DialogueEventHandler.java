package com.example.dialogue.client.events;

import com.example.dialogue.client.screen.DialogueScreen;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.npc.Villager;

@Mod.EventBusSubscriber
public class DialogueEventHandler {

    @SubscribeEvent
    public static void onRightClickVillager(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Villager)) return;

        if (event.getSide().isClient()) {
            Minecraft.getInstance().setScreen(
                    new DialogueScreen(Component.literal("Greetings, traveler!"))
            );
        }

        event.setCanceled(true);
    }
}
