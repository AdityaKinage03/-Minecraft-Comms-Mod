package com.example.dialogue.client.screen;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DialogueScreen extends Screen {

    private final Component dialogueText;
    private final List<Button> optionButtons = new ArrayList<>();
    private static final Random random = new Random();

    public DialogueScreen(Component dialogueText) {
        super(Component.literal("Dialogue"));
        this.dialogueText = dialogueText;
    }

    @Override
    protected void init() {
        super.init();
        optionButtons.clear();

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // Example options
        addDialogueOption(centerX - 100, centerY, "Who are you?", () -> {
            this.minecraft.setScreen(new DialogueScreen(Component.literal("I am just a humble villager.")));
        });

        addDialogueOption(centerX - 100, centerY + 30, "Trade with me", () -> {
            this.minecraft.player.sendSystemMessage(Component.literal("Opening trading..."));
            this.onClose();
        });

        // Quest options
        addDialogueOption(centerX - 100, centerY + 60, "Give me a Questline", this::assignQuest);

        addDialogueOption(centerX - 100, centerY + 90, "Check Quest", this::checkQuest);

        addDialogueOption(centerX - 100, centerY + 120, "Goodbye", () -> {
            this.minecraft.player.sendSystemMessage(Component.literal("Farewell, traveler!"));
            this.onClose();
        });
    }

    private void addDialogueOption(int x, int y, String text, Runnable action) {
        Button button = Button.builder(Component.literal(text), (btn) -> action.run())
                .bounds(x, y, 200, 20)
                .build();
        this.addRenderableWidget(button);
        optionButtons.add(button);
    }

    // ----------------------------
    // QUEST SYSTEM
    // ----------------------------
    private void assignQuest() {
        String[] quests = {
                "Defeat 5 zombies",
                "Collect 10 wheat",
                "Bring me 3 emeralds"
        };

        String chosenQuest = quests[random.nextInt(quests.length)];

        this.minecraft.player.getPersistentData().putString("activeQuest", chosenQuest);
        this.minecraft.player.getPersistentData().putInt("questProgress", 0);
        this.minecraft.player.getPersistentData().putInt("questTarget", getQuestTarget(chosenQuest));
        this.minecraft.player.getPersistentData().putBoolean("questComplete", false);

        this.minecraft.setScreen(new DialogueScreen(Component.literal(
                "Your quest: " + chosenQuest + ". Come back when you're done."
        )));
    }

    private void checkQuest() {
        boolean completed = this.minecraft.player.getPersistentData().getBoolean("questComplete");
        if (completed) {
            String quest = this.minecraft.player.getPersistentData().getString("activeQuest");
            completeQuest(quest);

            // Clear quest data
            this.minecraft.player.getPersistentData().remove("activeQuest");
            this.minecraft.player.getPersistentData().remove("questProgress");
            this.minecraft.player.getPersistentData().remove("questTarget");
            this.minecraft.player.getPersistentData().remove("questComplete");

        } else {
            String quest = this.minecraft.player.getPersistentData().getString("activeQuest");
            if (quest.isEmpty()) {
                this.minecraft.setScreen(new DialogueScreen(Component.literal("You don't have an active quest.")));
            } else {
                int progress = this.minecraft.player.getPersistentData().getInt("questProgress");
                int target = this.minecraft.player.getPersistentData().getInt("questTarget");
                this.minecraft.setScreen(new DialogueScreen(Component.literal(
                        "Quest in progress: " + quest + " (" + progress + "/" + target + ")"
                )));
            }
        }
    }

    private int getQuestTarget(String quest) {
        if (quest.contains("zombies")) return 5;
        if (quest.contains("wheat")) return 10;
        if (quest.contains("emeralds")) return 3;
        return 1;
    }

    private void completeQuest(String quest) {
        this.minecraft.player.sendSystemMessage(Component.literal("Quest Completed: " + quest));
        giveReward();
    }

    private void giveReward() {
        // Reward pool
        ItemStack[] rewardPool = {
                new ItemStack(Items.DIAMOND, random.nextInt(2) + 1),
                new ItemStack(Items.IRON_INGOT, random.nextInt(5) + 3),
                new ItemStack(Items.GOLD_INGOT, random.nextInt(4) + 2),
                new ItemStack(Items.EMERALD, random.nextInt(4) + 1),
                new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 1),
                new ItemStack(Items.DIAMOND_SWORD, 1),
                new ItemStack(Items.NETHERITE_SCRAP, random.nextInt(2) + 1),
                new ItemStack(Items.EXPERIENCE_BOTTLE, random.nextInt(5) + 1),
                new ItemStack(Items.BREAD, random.nextInt(6) + 3),
                new ItemStack(Items.SHIELD, 1),
                new ItemStack(Items.BOW, 1),
                new ItemStack(Items.COOKED_BEEF, random.nextInt(5) + 2)
        };

        ItemStack chosenReward = rewardPool[random.nextInt(rewardPool.length)];

        boolean success = this.minecraft.player.getInventory().add(chosenReward);
        if (!success) {
            this.minecraft.player.drop(chosenReward, false);
        }

        int xp = random.nextInt(15) + 5; // 5–20 XP
        this.minecraft.player.giveExperiencePoints(xp);

        this.minecraft.player.sendSystemMessage(
                Component.literal("You received: " + chosenReward.getDisplayName().getString() +
                        " and " + xp + " XP!")
        );
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(guiGraphics);
        guiGraphics.drawCenteredString(this.font, dialogueText, this.width / 2, this.height / 2 - 60, 0xFFFFFF);
        super.render(guiGraphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
